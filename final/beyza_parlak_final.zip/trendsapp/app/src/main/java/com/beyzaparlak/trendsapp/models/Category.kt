package com.beyzaparlak.trendsapp.models

data class Category(
    val name: String,
    val slug: String,
    val url: String
)
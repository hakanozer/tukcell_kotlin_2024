package com.beyzaparlak.trendsapp.models

data class Dimensions(
    val depth: Double,
    val height: Double,
    val width: Double
)
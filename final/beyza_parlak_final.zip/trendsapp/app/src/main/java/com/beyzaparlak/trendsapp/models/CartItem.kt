package com.beyzaparlak.trendsapp.models

data class CartItem(
    val productId: Int,
    val quantity: Int
)
package com.beyzaparlak.trendsapp.configs

data class LoginRequest(
    val username: String, val password: String
)
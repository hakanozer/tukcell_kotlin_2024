package com.beyzaparlak.trendsapp.configs

data class LoginResponse(
    val token: String,
    val id: Int
)
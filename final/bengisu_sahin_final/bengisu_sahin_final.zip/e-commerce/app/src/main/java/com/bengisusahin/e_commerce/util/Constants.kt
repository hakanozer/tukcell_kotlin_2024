package com.bengisusahin.e_commerce.util

object Constants {
    const val BASE_URL = "https://dummyjson.com/"
}
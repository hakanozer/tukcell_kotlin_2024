package com.bengisusahin.e_commerce.data.dataCategories

data class CategoriesItem(
    val name: String,
    val slug: String,
    val url: String
)
package com.bengisusahin.e_commerce.data.dataProduct

data class Dimensions(
    val depth: Double,
    val height: Double,
    val width: Double
)
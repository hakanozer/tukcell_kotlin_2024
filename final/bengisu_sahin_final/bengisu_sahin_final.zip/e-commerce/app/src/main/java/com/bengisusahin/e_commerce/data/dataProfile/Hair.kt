package com.bengisusahin.e_commerce.data.dataProfile

data class Hair(
    val color: String,
    val type: String
)
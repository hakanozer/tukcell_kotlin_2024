package com.bengisusahin.e_commerce.data.dataAuth

data class LoginRequest(
    val username: String,
    val password: String
)

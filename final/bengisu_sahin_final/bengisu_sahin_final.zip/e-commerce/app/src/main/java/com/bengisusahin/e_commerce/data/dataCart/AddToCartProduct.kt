package com.bengisusahin.e_commerce.data.dataCart

data class AddToCartProduct(
    val id: Int,
    val quantity: Int
)

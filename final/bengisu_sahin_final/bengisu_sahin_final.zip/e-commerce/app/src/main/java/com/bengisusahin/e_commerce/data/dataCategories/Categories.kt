package com.bengisusahin.e_commerce.data.dataCategories

class Categories : ArrayList<CategoriesItem>()
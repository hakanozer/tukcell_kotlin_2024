package com.bengisusahin.e_commerce.data.dataProfile

data class Company(
    val address: Address,
    val department: String,
    val name: String,
    val title: String
)
package com.bengisusahin.e_commerce.data.dataProfile

data class Crypto(
    val coin: String,
    val network: String,
    val wallet: String
)
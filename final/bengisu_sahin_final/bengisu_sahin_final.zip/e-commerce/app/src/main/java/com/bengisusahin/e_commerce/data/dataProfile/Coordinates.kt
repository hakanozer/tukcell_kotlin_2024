package com.bengisusahin.e_commerce.data.dataProfile

data class Coordinates(
    val lat: Double,
    val lng: Double
)
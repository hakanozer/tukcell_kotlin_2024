# e-commerce
 It is an Android Kotlin shop app

package com.emrecura.easyshop.models

data class Category(
    val slug: String,
    val name: String,
    val url: String
)

package com.emrecura.easyshop.models

data class UserLogin(
    val username: String,
    val password: String
)

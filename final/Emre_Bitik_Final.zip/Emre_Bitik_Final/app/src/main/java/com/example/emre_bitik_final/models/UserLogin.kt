package com.example.emre_bitik_final.models

data class UserLogin(
    val username: String,
    val password: String
)

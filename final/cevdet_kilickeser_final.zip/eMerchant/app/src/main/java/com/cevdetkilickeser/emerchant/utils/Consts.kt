package com.cevdetkilickeser.emerchant.utils

const val channelId = "notification_channel"
const val channelName = "com.cevdetkilickeser.emerchant"
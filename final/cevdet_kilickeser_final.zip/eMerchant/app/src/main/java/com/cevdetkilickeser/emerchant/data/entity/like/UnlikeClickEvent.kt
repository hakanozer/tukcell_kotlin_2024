package com.cevdetkilickeser.emerchant.data.entity.like

data class UnlikeClickEvent(val like: Like)

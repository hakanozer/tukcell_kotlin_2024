package com.cevdetkilickeser.emerchant.data.entity.user

data class LoginRequest(val username: String, val password: String)
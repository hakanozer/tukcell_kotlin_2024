package com.cevdetkilickeser.emerchant.data.order

data class OrderProduct(val productId: Int, val quantity: Int)

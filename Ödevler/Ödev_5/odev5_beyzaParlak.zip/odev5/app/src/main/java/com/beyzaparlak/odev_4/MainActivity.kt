package com.beyzaparlak.odev_4

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.beyzaparlak.odev_4.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // butona tıklandığında
        binding.btnDetail.setOnClickListener {

            // butona tıkladığımızda, ilgili sahneye geçer. birinci parametre, terkedilecek sınıftır
            val i = Intent(this, ProfileActivity::class.java)
            // ilgili sahneyi açar
            startActivity(i)

            // bu nesneyi finish() ile öldürebiliriz fakat şuan uygun görmediğim için eklemedim
        }


    }
}
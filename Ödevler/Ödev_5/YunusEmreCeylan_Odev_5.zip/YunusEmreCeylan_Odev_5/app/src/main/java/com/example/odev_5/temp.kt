package com.example.odev_5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class temp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_temp)
    }
}